cat <<'EOF' >/usr/local/sbin/autoremove-all.sh
#!/bin/bash
# ==========================================
# AUTO REMOVE EXPIRED USERS
# XRAY + SSH ONLY
# SHOW DELETED USERS + TOTAL COUNT
# SAFE FOR CRON & MANUAL
# ==========================================

TODAY=$(date +"%Y-%m-%d")

# Deteksi manual / cron
MANUAL_RUN=false
[[ -t 1 ]] && MANUAL_RUN=true

# Counter
XRAY_DEL=0
SSH_DEL=0
DELETED_LIST=""

################################
# AUTO REMOVE XRAY
################################
XRAY_CFG="/etc/xray/config.json"

remove_xray() {
  tag="$1"
  grep "^$tag" "$XRAY_CFG" 2>/dev/null | awk '{print $2,$3}' | while read -r user exp; do
    if [[ "$exp" < "$TODAY" ]]; then
      sed -i "/^$tag $user $exp/,/^},{/d" "$XRAY_CFG"
      XRAY_DEL=$((XRAY_DEL + 1))
      DELETED_LIST+="[XRAY] $user (exp $exp)\n"
    fi
  done
}

if [[ -f "$XRAY_CFG" ]]; then
  remove_xray "###"
  remove_xray "#&"
  remove_xray "#!"
  remove_xray "#!#"
  systemctl restart xray >/dev/null 2>&1
fi

################################
# AUTO REMOVE SSH
################################
SSH_DB="/etc/ssh/.ssh.db"

if [[ -f "$SSH_DB" ]]; then
  tmp=$(mktemp)
  while read -r line; do
    user=$(awk '{print $2}' <<< "$line")
    exp=$(awk '{print $3}' <<< "$line")
    if [[ "$exp" < "$TODAY" ]]; then
      userdel --force "$user" >/dev/null 2>&1
      SSH_DEL=$((SSH_DEL + 1))
      DELETED_LIST+="[SSH] $user (exp $exp)\n"
    else
      echo "$line" >> "$tmp"
    fi
  done < <(grep "^###" "$SSH_DB")
  mv "$tmp" "$SSH_DB"
  systemctl reload ssh >/dev/null 2>&1
fi

################################
# OUTPUT (MANUAL SAJA)
################################
if $MANUAL_RUN; then
  TOTAL_DEL=$((XRAY_DEL + SSH_DEL))

  clear
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo " AUTO REMOVE EXPIRED ACCOUNT"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo
  echo "Tanggal : $TODAY"
  echo

  if [[ "$TOTAL_DEL" -gt 0 ]]; then
    echo "Akun Terhapus:"
    echo -e "$DELETED_LIST"
  else
    echo "Tidak ada akun expired hari ini"
  fi

  echo
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "Total XRAY : $XRAY_DEL"
  echo "Total SSH  : $SSH_DEL"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "TOTAL AKUN TERHAPUS : $TOTAL_DEL"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo
  read -rp "Enter untuk kembali ke menu-system"
  clear
  command -v menu-system >/dev/null && menu-system
fi

exit 0
EOF

chmod +x /usr/local/sbin/autoremove-all.sh