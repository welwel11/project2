cat <<'EOF' >/usr/local/sbin/autoremove-all.sh
#!/bin/bash
# ==========================================
# AUTO REMOVE EXPIRED USERS
# XRAY + SSH ONLY
# SAFE FOR CRON & MANUAL
# ==========================================

TODAY=$(date +"%Y-%m-%d")
MANUAL_RUN=false
[[ -t 1 ]] && MANUAL_RUN=true

XRAY_DEL=0
SSH_DEL=0
DELETED_LIST=""

XRAY_CFG="/etc/xray/config.json"

remove_xray() {
  tag="$1"
  grep "^$tag" "$XRAY_CFG" 2>/dev/null | awk '{print $2,$3}' | while read -r user exp; do
    [[ "$exp" < "$TODAY" ]] || continue
    sed -i "/^$tag $user $exp/,/^},{/d" "$XRAY_CFG"
    XRAY_DEL=$((XRAY_DEL + 1))
    DELETED_LIST+="[XRAY] $user (exp $exp)\n"
  done
}

[[ -f "$XRAY_CFG" ]] && {
  remove_xray "###"
  remove_xray "#&"
  remove_xray "#!"
  remove_xray "#!#"
  systemctl restart xray >/dev/null 2>&1
}

SSH_DB="/etc/ssh/.ssh.db"

[[ -f "$SSH_DB" ]] && {
  tmp=$(mktemp)
  grep "^###" "$SSH_DB" | while read -r line; do
    user=$(awk '{print $2}' <<< "$line")
    exp=$(awk '{print $3}' <<< "$line")
    if [[ "$exp" < "$TODAY" ]]; then
      userdel --force "$user" >/dev/null 2>&1
      SSH_DEL=$((SSH_DEL + 1))
      DELETED_LIST+="[SSH] $user (exp $exp)\n"
    else
      echo "$line" >> "$tmp"
    fi
  done
  mv "$tmp" "$SSH_DB"
  systemctl reload ssh >/dev/null 2>&1
}

if $MANUAL_RUN; then
  TOTAL_DEL=$((XRAY_DEL + SSH_DEL))
  clear
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo " AUTO REMOVE EXPIRED ACCOUNT"
  echo "Tanggal : $TODAY"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  [[ "$TOTAL_DEL" -gt 0 ]] && echo -e "$DELETED_LIST" || echo "Tidak ada akun expired"
  echo
  echo "XRAY : $XRAY_DEL | SSH : $SSH_DEL | TOTAL : $TOTAL_DEL"
  read -rp "Enter untuk kembali"
fi
exit 0
EOF

chmod +x /usr/local/sbin/autoremove-all.sh && \
ln -sf /usr/local/sbin/autoremove-all.sh /usr/bin/autoremove && \
(crontab -l 2>/dev/null; echo "0 0 * * * /usr/local/sbin/autoremove-all.sh >/dev/null 2>&1") | crontab -