#!/bin/bash

RED="\033[31m"
YELLOW="\033[33m"
NC='\e[0m'
Lgreen='\033[92m'
PURPLE='\033[35m'

BURIQ () {
    curl -sS https://raw.githubusercontent.com/welwel11/izin/main/izin > /root/tmp
    data=( `cat /root/tmp | grep -E "^#vm# " | awk '{print $2}'` )
    for user in "${data[@]}"
    do
    exp=( `grep -E "^#vm# $user" "/root/tmp" | awk '{print $3}'` )
    d1=(`date -d "$exp" +%s`)
    d2=(`date -d "$biji" +%s`)
    exp2=$(( (d1 - d2) / 86400 ))
    if [[ "$exp2" -le "0" ]]; then
    echo $user > /etc/.$user.ini
    else
    rm -f /etc/.$user.ini > /dev/null 2>&1
    fi
    done
}

MYIP=$(curl -sS ipv4.icanhazip.com)
Name=$(curl -sS https://raw.githubusercontent.com/welwel11/izin/main/izin | grep $MYIP | awk '{print $2}')
echo $Name > /usr/local/etc/.$Name.ini
CekOne=$(cat /usr/local/etc/.$Name.ini)

Bloman () {
if [ -f "/etc/.$Name.ini" ]; then
CekTwo=$(cat /etc/.$Name.ini)
    if [ "$CekOne" = "$CekTwo" ]; then
        res="Expired"
    fi
else
res="Permission Accepted..."
fi
}

PERMISSION () {
    MYIP=$(curl -sS ipv4.icanhazip.com)
    IZIN=$(curl -sS https://raw.githubusercontent.com/welwel11/izin/main/izin | awk '{print $4}' | grep $MYIP)
    if [ "$MYIP" = "$IZIN" ]; then
    Bloman
    else
    res="Permission Denied!"
    fi
    BURIQ
}
red='\e[1;31m'
green='\e[1;32m'
NC='\e[0m'
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
PERMISSION
if [ -f /home/needupdate ]; then
red "Your script need to update first !"
exit 0
elif [ "$res" = "Permission Accepted..." ]; then
echo -ne
else
red "Permission Denied!"
exit 0
fi

clear
function con() {
    local -i bytes=$1
    if [[ $bytes -lt 1024 ]]; then
        echo "${bytes}B"
    elif [[ $bytes -lt 1048576 ]]; then
        echo "$(( (bytes + 1023)/1024 ))KB"
    elif [[ $bytes -lt 1073741824 ]]; then
        echo "$(( (bytes + 1048575)/1048576 ))MB"
    else
        echo "$(( (bytes + 1073741823)/1073741824 ))GB"
    fi
}

clear
echo -e "${Lgreen}◈━━━━━━━━━━━━━━━━━◈◈━━━━━━━━━━━━━━━━━◈ ${NC}"
echo -e "        CEK USAGE QUOTA AKUN TROJAN      "
echo -e "${Lgreen}◈━━━━━━━━━━━━━━━━━◈◈━━━━━━━━━━━━━━━━━◈ ${NC}"

data=( `grep '^#vm#' /etc/xray/config.json | cut -d ' ' -f 2 | sort | uniq` )

for akun in "${data[@]}"; do
    if [[ -z "$akun" ]]; then
        akun="tidakada"
    fi
    
    byte=$(cat /etc/vmess/${akun}) 2>/dev/null
    if [[ -z "$byte" ]]; then
        byte=0
    fi
    
    usage_quota=$(con $byte)
    
    lim=$(cat /etc/limit/vmess/${akun}) 2>/dev/null
    if [[ -z "$lim" ]]; then
        lim=0
    fi
    limit_quota=$(con $lim)

    # Mendapatkan waktu login
    last_login=$(grep -w "$akun" /var/log/xray/access.log | tail -n 1 | awk '{print $2}') 2>/dev/null
    if [[ -z "$last_login" ]]; then
        last_login="Tidak ada"
    fi
    
    ip_count=$(grep -w "$akun" /var/log/xray/access.log | awk '{print $3}' | sed 's/tcp://g' | cut -d ':' -f 1 | sort | uniq | wc -l)

    echo -e "${PURPLE}◈━━━━━━━━━━━━━━━━━◈◈━━━━━━━━━━━━━━━━━◈ ${NC}"
    printf "    %-13s %-7s\n" "UserName : ${akun}"
    printf "    %-13s %-7s\n" "Total Bandwidth : ${limit_quota}" 
    printf "    %-13s %-7s\n" "Last Login : ${last_login}"
    printf "    %-13s %-7s\n" "Login IP : ${ip_count}"
    echo -e "${PURPLE}◈━━━━━━━━━━━━━━━━━◈◈━━━━━━━━━━━━━━━━━◈ ${NC}"
done

echo ""
read -p "Enter Untuk Kembali Ke Menu"
menu-vmess